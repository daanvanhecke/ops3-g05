# YOmoni

Siege testing made easy

## Prerequisites

- [Siege](https://github.com/HoGentTIN/ops3-g05/blob/master/Linux/Loadtesters/installatie%20siege%20op%20ubuntu.md) is installed and configured. (Follow link for instructions)
- Python package (For a simple HTTP-server) 

## Installation
- Download files
- personalise the config.cfg

## Run
In YOmoni root folder, run ```sudo ./runsiege.sh``` in terminal. Follow the instructions.
In Yomoni/Website folder, run ```python -m simpleHTTPServer```

After tests are done, visit ```localhost:8000``` in your favorite browser.

